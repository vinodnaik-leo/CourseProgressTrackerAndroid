# Course Progress Tracker Pro Android

Android Studio project wrapper around the original tracker HTML. Runs offline in a WebView and stores browser-side data using the page's web storage.

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync/downloads.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK location: `app/build/outputs/apk/debug/app-debug.apk`.

Or push this project to a GitHub repository; the workflow under `.github/workflows/build-apk.yml` builds a debug APK and attaches it to the workflow run.
